<?php

namespace Model;

class Proveedor extends ActiveRecord{
    //Base de datos
    protected static $tabla = 'proveedor';
    protected static $columnasDB = ['id', 'nombrecomercial', 'nombrefiscal', 'domicilio', 'no_contacto', 'metodo_pago', 'diascredito'];
 
    public $id;
    public $nombrecomercial;
    public $nombrefiscal;
    public $domicilio;
    public $no_contacto;
    public $metodo_pago;
    public $diascredito;

    public function __construct($args = [])
    {
        $this->id = $args['id'] ?? null;
        $this->nombrecomercial = $args['nombrecomercial'] ?? '';
        $this->nombrefiscal = $args['nombrefiscal'] ?? '';
        $this->domicilio = $args['domicilio'] ?? '';
        $this->no_contacto = $args['no_contacto'] ?? '';
        $this->metodo_pago = $args['metodo_pago'] ?? '';
        $this->diascredito = $args['diascredito'] ?? '';
    }
}