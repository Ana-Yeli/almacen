<?php

namespace Model;

class Categoria extends ActiveRecord{
    //Base de datos
    protected static $tabla = 'categoria';
    protected static $columnasDB = ['id', 'clave', 'nombre'];
 
    public $id;
    public $clave;
    public $nombre;

    public function __construct($args = [])
    {
        $this->id = $args['id'] ?? null;
        $this->clave = $args['clave'] ?? null;
        $this->nombre = $args['nombre'] ?? '';

    }
}