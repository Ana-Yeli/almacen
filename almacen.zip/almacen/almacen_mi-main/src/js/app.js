const entradas = {
  tipo: "",
  fechaEntrada: "",
  fechaRecepcion: "",
  subtotal: "",
  folio: "",
  usuario: "",
  productos: {
    nombre: "",
    codigo: "",
    descripcion: "",
    fechaCaducidad: "",
    unidadMedida: [],
    tamaño: "",
    IVA: "",
    total: "",
    Marca: [],
    Categoria: [],
    Subcategoria: [],
  },
  Proveedor: [],
};

document.addEventListener("DOMContentLoaded", function () {
  iniciarApp();
});

function iniciarApp() {
  consultarAPI(); //Consulta la API en el backend de PHP
  nombreCliente(); //Añade el nombre del usuario al objeto entradas
  seleccionarFechacaducidad(); // Añade la fecha de caducidad del producto
  seleccionarFechaRecepcion();
}

async function consultarAPI() {
  try {
    const urlcategoria = "http://localhost:3000/api/categoria";
    const urlsubcategoria = "http://localhost:3000/api/subcategoria";
    const urlmarca = "http://localhost:3000/api/marca";
    const urlproveedor = "http://localhost:3000/api/proveedor";
    //const urlusuario = 'http://localhost:3000/api/usuario';

    const resulcat = await fetch(urlcategoria);
    const resulsubcat = await fetch(urlsubcategoria);
    const resulmarc = await fetch(urlmarca);
    const resultprov = await fetch(urlproveedor);
    // const resultusu = await fetch(urlusuario);

    const categoria = await resulcat.json();
    const subcategoria = await resulsubcat.json();
    const marca = await resulmarc.json();
    const proveedor = await resultprov.json();
    //const usuario = await resultusu.json();

    const medida = [
      { id: 1, nombre: "Pieza" },
      { id: 2, nombre: "Paquete" },
    ];

    const tipoEntrada = [
      { id: 1, nombre: "Nota" },
      { id: 2, nombre: "Remisión" },
    ];

    mostrarMarca(marca);
    mostrarCategoria(categoria);
    mostrarSubcategoria(subcategoria);
    mostrarProveedor(proveedor);
    mostrarMedida(medida);
    mostrarTipoentrada(tipoEntrada);
  } catch (error) {
    console.log(error);
  }
}

function mostrarCategoria(categoria) {
  categoria.forEach((cate, index) => {
    const { id, clave, nombre } = cate;
    index = index + 1; // -- slecciona +1, los arreglos inician en 0, + 1 = +2

    const nombreCategoria = document.createElement("option");
    nombreCategoria.textContent = nombre;
    nombreCategoria.dataset.id = id;
    nombreCategoria.value = index;
    document.querySelector("#categoria").appendChild(nombreCategoria);
  });
  // Evento para mostrar el objeto seleccionado cuando cambia la selección del dropdown
  document.querySelector("#categoria").addEventListener("change", function () {
    const seleccionado = document.querySelector("#categoria option:checked");
    const id = parseInt(seleccionado.value);

    const categorias = document.querySelector("#categoria").children;
    const categoriaSeleccionada = categorias[id];
    // Buscar la categoría seleccionada en el array de categorías
    const resultado = categoria.find(
      (cate) => cate.id === categoriaSeleccionada.value
    );
    //console.log(resultado);
    // Llamar a la función para seleccionar la categoría
    seleccionarCategoria(resultado);
  });
}
function mostrarSubcategoria(subcategoria) {
  subcategoria.forEach((subcate, index) => {
    const { id, clave, nombre } = subcate;
    index = index + 1;

    const nombreSubcategoria = document.createElement("option");
    nombreSubcategoria.textContent = nombre;
    nombreSubcategoria.dataset.id = id;
    nombreSubcategoria.value = index;
    document.querySelector("#subcategoria").appendChild(nombreSubcategoria);
  });
  //Evento para mostrar el objeto seleccionado cuando cambia la selección del dropdown
  document
    .querySelector("#subcategoria")
    .addEventListener("change", function () {
      const seleccionado = document.querySelector(
        "#subcategoria option:checked"
      );
      const id = parseInt(seleccionado.value);

      const subcategorias = document.querySelector("#subcategoria").children;
      const subcategoriaSeleccionada = subcategorias[id];
      //Buscar la subcategoría seleccionada en el array de subcategorías
      const resultado = subcategoria.find(
        (subcate) => subcate.id === subcategoriaSeleccionada.value
      );
      //console.log(resultado);
      // Llamar a la función para seleccionar la categoría
      seleccionarSubcategoria(resultado);
    });
}
function mostrarMarca(marca) {
  marca.forEach((mark, index) => {
    const { id, clave, nombre } = mark;
    index = index + 1;

    const nombreMarca = document.createElement("option");
    nombreMarca.textContent = nombre;
    nombreMarca.dataset.id = id;
    nombreMarca.value = index;
    document.querySelector("#marca").appendChild(nombreMarca);
  });
  //Evento para mostrar el objeto seleccionado cuando cambia la selección del dropdown
  document.querySelector("#marca").addEventListener("change", function () {
    const seleccionado = document.querySelector("#marca option:checked");
    const id = parseInt(seleccionado.value);
    //console.log(id);
    const marcas = document.querySelector("#marca").children;
    const marcaSeleccionada = marcas[id];
    //console.log(marcaSeleccionada);
    //Buscar la marca seleccionada en el array de marcas
    const resultado = marca.find((mark) => mark.id === marcaSeleccionada.value);
    //console.log(resultado);
    // Llamar a la función para seleccionar la categoría
    seleccionarMarca(resultado);
  });
}
function mostrarMedida(medida) {
  medida.forEach((extent, index) => {
    const { id, nombre } = extent;
    index = index + 1;

    const nombreMedida = document.createElement("option");
    nombreMedida.textContent = nombre;
    nombreMedida.dataset.id = id;
    nombreMedida.value = index;
    document.querySelector("#unidad_medida").appendChild(nombreMedida);
  });
  //Evento para mostrar el objeto seleccionado cuando cambia la selección del dropdown
  document
    .querySelector("#unidad_medida")
    .addEventListener("change", function () {
      const seleccionado = document.querySelector(
        "#unidad_medida option:checked"
      );
      const id = parseInt(seleccionado.value);

      const resultado = medida.find((extent) => extent.id === id);
      //console.log(resultado);
      // Llamar a la función para seleccionar la categoría
      seleccionarMedida(resultado);
    });
}
function seleccionarCategoria(resultado) {
  const { Categoria } = entradas.productos;

  entradas.productos.Categoria = { ...Categoria, resultado };

  //console.log(entradas);
}
function seleccionarSubcategoria(resultado) {
  const { Subcategoria } = entradas.productos;

  entradas.productos.Subcategoria = { ...Subcategoria, resultado };

  //console.log(productos);
}
function seleccionarMarca(resultado) {
  const { Marca } = entradas.productos;

  entradas.productos.Marca = { ...Marca, resultado };

  //console.log(productos);
}
function seleccionarMedida(resultado) {
  const { unidadMedida } = entradas.productos;

  entradas.productos.unidadMedida = { ...unidadMedida, resultado };
  //console.log(entradas);
}
function seleccionarFechacaducidad() {
  const inputFechacaducidad = document.querySelector("#fecha_caducidad");
  inputFechacaducidad.addEventListener("input", function () {
    entradas.productos.fechaCaducidad = inputFechacaducidad.value;
    //console.log(entradas);
  });
}
function nombreCliente() {
  const nombreStrong = document.querySelector("#nombreusuario");
  entradas.usuario = nombreStrong.textContent;
  //console.log(entradas);
}
function mostrarTipoentrada(tipoEntrada) {
  tipoEntrada.forEach((inputtype, index) => {
    const { id, nombre } = inputtype;
    index = index + 1;

    const nombreTipoentrada = document.createElement("option");
    nombreTipoentrada.textContent = nombre;
    nombreTipoentrada.dataset.id = id;
    nombreTipoentrada.value = index;
    document.querySelector("#tipo_entrada").appendChild(nombreTipoentrada);
  });
  //Evento para mostrar el objeto seleccionado cuando cambia la selección del dropdown
  document
    .querySelector("#tipo_entrada")
    .addEventListener("change", function () {
      const seleccionado = document.querySelector(
        "#tipo_entrada option:checked"
      );
      const id = parseInt(seleccionado.value);

      const resultado = tipoEntrada.find((inputtype) => inputtype.id === id);
      //console.log(resultado);
      // Llamar a la función para seleccionar la categoría
      seleccionarTipoentrada(resultado);
    });
}
function mostrarProveedor(proveedor) {
  proveedor.forEach((suplier, index) => {
    const {
      id,
      nombrecomercial,
      nombrefiscal,
      domicilio,
      no_contacto,
      metodo_pago,
      diascredito,
    } = suplier;
    index = index + 1;

    const nombreProveedor = document.createElement("OPTION");
    nombreProveedor.textContent = nombrecomercial;
    nombreProveedor.dataset.id = id;
    nombreProveedor.value = index;
    document.querySelector("#proveedor").appendChild(nombreProveedor);
  });
  //Evento para mostrar el objeto seleccionado cuando cambia la selección del dropdown
  document.querySelector("#proveedor").addEventListener("change", function () {
    const seleccionado = document.querySelector("#proveedor option:checked");
    const id = parseInt(seleccionado.value);
    //console.log(id);
    const proveedores = document.querySelector("#proveedor").children;
    const proveedorSeleccionado = proveedores[id];
    //console.log(marcaSeleccionada);
    //Buscar la marca seleccionada en el array de marcas
    const resultado = proveedor.find(
      (suplier) => suplier.id === proveedorSeleccionado.value
    );
    //console.log(resultado);
    // Llamar a la función para seleccionar la categoría
    seleccionarProveedor(resultado);
  });
}
function seleccionarTipoentrada(resultado) {
  const { tipo } = entradas;

  entradas.tipo = { ...tipo, resultado };
  //console.log(entradas);
}
function seleccionarProveedor(resultado) {
  const { Proveedor } = entradas;

  entradas.Proveedor = { ...Proveedor, resultado };

  //console.log(entradas);
}
function seleccionarFechaRecepcion() {
  const inputFecha = document.querySelector("#fecha_recepcion");
  inputFecha.addEventListener("input", function () {
    entradas.fechaRecepcion = inputFecha.value;
    console.log(entradas);
  });
}
// Función para obtener la fecha y hora actual en formato 'YYYY-MM-DD HH:MM:SS'
function obtenerFechaHoraActual() {
  const fechaHoraActual = new Date();

  const anio = fechaHoraActual.getFullYear();
  const mes = (fechaHoraActual.getMonth() + 1).toString().padStart(2, "0");
  const dia = fechaHoraActual.getDate().toString().padStart(2, "0");

  const horas = fechaHoraActual.getHours().toString().padStart(2, "0");
  const minutos = fechaHoraActual.getMinutes().toString().padStart(2, "0");
  const segundos = fechaHoraActual.getSeconds().toString().padStart(2, "0");

  const fechaHoraFormateada = `${anio}-${mes}-${dia} ${horas}:${minutos}:${segundos}`;
  return fechaHoraFormateada;
}
// Llamamos a la función para obtener la fecha y hora actual y la asignamos a 'fechaEntrada'
entradas.fechaEntrada = obtenerFechaHoraActual();
//console.log(entradas.fechaEntrada); // Imprime la fecha y hora actual en formato 'YYYY-MM-DD HH:MM:SS'

//funcion para crear un producto
function crearProducto() {
  const producto = document.createElement("tr");
  producto.innerHTML = `

    <td class="px-6 py-4 whitespace-nowrap">
        <div class="flex items-center">
            <div class="flex-shrink-0 h-10 w-10">
                <img class="h-10 w-10 rounded-full"
                    src="https://cdn.pixabay.com/photo/2015/04/23/22/00/tree-736885__480.jpg"
                    alt="">
            </div>
            <div class="ml-4">
                <div class="text-sm font-medium text-gray-900">
                    ${entradas.productos.nombre}
                </div>
                <div class="text-sm text-gray-500">
                    ${entradas.productos.descripcion}
                </div>
            </div>
        </div>
    </td>
    <td class="px-6 py-4 whitespace-nowrap">
        <div class="text-sm text-gray-900">${entradas.productos.codigo}</div>
        <div class="text-sm text-gray-500">Código</div>
    </td>
    <td class="px-6 py-4 whitespace-nowrap">
        <span
            class="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-green-100 text-green-800">
            ${entradas.productos.unidadMedida.nombre}
        </span>
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.productos.tamaño}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.productos.fechaCaducidad}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.productos.IVA}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.productos.total}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.productos.Marca.nombre}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.productos.Categoria.nombre}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.productos.Subcategoria.nombre}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.Proveedor.nombrecomercial}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.Proveedor.nombrefiscal}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.Proveedor.domicilio}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.Proveedor.no_contacto}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.Proveedor.metodo_pago}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.Proveedor.diascredito}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.fechaEntrada}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.usuario}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.tipo.nombre}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.folio}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.subtotal}
    </td>
    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
        ${entradas.productos.total}
    </td> `;
}
