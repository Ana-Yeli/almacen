<?php

namespace Controllers;

use MVC\Router;

class FacturaController{
    

    public static function index(Router $router){

        $router->rend('factura/index', [
        'nombre' => $_SESSION['nombre'],
        'email' => $_SESSION['email']
        
        ]);
    }
    public static function dash(Router $router){
    
        
        $router->rend('dashboard/index', [
        'nombre' => $_SESSION['nombre'],
        'email' => $_SESSION['email']
        ]);
    }
}