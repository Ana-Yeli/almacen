<?php

namespace Controllers;

use Model\Categoria;
use Model\Subcategoria;
use Model\Marca;
use Model\Proveedor;
use Model\Usuario;

class APIController{

    public static function categoria(){
        $categoria = Categoria::all();
        echo json_encode($categoria);
    }

    public static function subcategoria(){
        $subcategoria = Subcategoria::all();
        echo json_encode($subcategoria);
    }

    public static function marca(){
        $marca = Marca::all();
        echo json_encode($marca);
    }

    public static function proveedor(){
        $proveedor = Proveedor::all();
        echo json_encode($proveedor);
    }
    public static function usuario(){
        $usuario = Usuario::all();
        echo json_encode($usuario);
    }
}