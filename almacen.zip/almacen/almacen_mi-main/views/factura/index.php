<div class="d-flex justify-content-between flex-wrap flex-md-nowrap align-items-center pt-3 pb-2 mb-3 border-bottom">
        <h1 class="h2">Entradas</h1>
        <div class="btn-toolbar mb-2 mb-md-0">
        </div>
</div>

<div class="container">
  <main>
    <div class="row g-5">
      <div class="col-md-5 col-lg-4 order-md-last">
        <h4 class="d-flex justify-content-between align-items-center mb-3">
          <span class="text-primary">Ticket</span>
          <span class="badge bg-primary rounded-pill">3</span>
        </h4>
        <ul class="list-group mb-3">
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Agua</h6>
              <small class="text-muted">Ciel</small>
            </div>
            <div>1</div>
            <span class="text-muted">$12</span>
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Toallitas</h6>
              <small class="text-muted">Huggies</small>
            </div>
            <div>1</div>
            <span class="text-muted">$42</span>
          </li>
          <li class="list-group-item d-flex justify-content-between lh-sm">
            <div>
              <h6 class="my-0">Galletas</h6>
              <small class="text-muted">Gamesa</small>
            </div>
            <div>1</div>
            <span class="text-muted">$5</span>
          </li>
          <li class="list-group-item d-flex justify-content-between bg-light">
            <div class="text-success">
              <h6 class="my-0">Proveedor</h6>
              <small>Bodega Aurrera</small>
            </div>
            <span class="text-success"></span>
          </li>
          <li class="list-group-item d-flex justify-content-between">
            <span>Total (MXN)</span>
            <strong>$59</strong>
          </li>
          <li class="list-group-item d-flex justify-content-between bg-light">
            <div class="text-primary">
              <h6 class="my-0">Codigo</h6>
              <span>1025968745</span>
            </div> 
          </li>
        </ul>
      </div>
      <div class="col-md-7 col-lg-8">
            <h4 class="mb-3">Ingresar productos</h4>
        <form class="needs-validation" novalidate>
          <div class="row g-3">

            <div class="col-sm-4">
              <label for="nombre" class="form-label">Nombre</label>
              <input type="text" class="form-control" id="nombre" placeholder="Nombre del producto" value="" required>
              <div class="invalid-feedback">
                El campo es obligatorio
              </div>
            </div>

              <div class="col-sm-4">
              <label for="categoria" class="form-label">Categoria</label>
              <select class="form-select" id="categoria" required>
                  <option value="">-- Selecciona --</option>
              </select>
              <div class="invalid-feedback">
                El campo es obligatorio
              </div>
            </div>

            <div class="col-sm-4">
              <label for="subcategoria" class="form-label">Subcategoria</label>
              <select class="form-select" id="subcategoria" required>
                  <option value="">-- Selecciona --</option>
                </select>
              <div class="invalid-feedback">
                El campo es obligatorio
              </div>
            </div>

            <div class="col-sm-4">
              <label for="marca" class="form-label">Marca</label>
                <select class="form-select" id="marca" required>
                  <option value="">-- Selecciona --</option>
                </select>
                <div class="invalid-feedback">
                El campo es obligatorio
                </div>
            </div>

            <div class="col-sm-4">
              <label for="unidad_medida" class="form-label">Unidad de medida</label>
              <select class="form-select" id="unidad_medida" required>
                  <option value="">-- Selecciona --</option>
                </select>
              <div class="invalid-feedback">
                El campo es obligatorio
              </div>
            </div>

            <div class="col-sm-4">
              <label for="codigo" class="form-label">Codigo</label>
              <input type="text" class="form-control" id="codigo" placeholder="Código del producto" value="" required>
              <div class="invalid-feedback">
                El campo es obligatorio
              </div>
            </div>

            <div class="col-sm-4">
              <label for="descripcion" class="form-label">Descripcion</label>
              <input type="text" class="form-control" id="descripcion" placeholder="Breve descripcion del producto" value="" required>
              <div class="invalid-feedback">
                El campo es obligatorio
              </div>
            </div>

            <div class="col-sm-4">
              <label for="fecha_caducidad" class="form-label">Fecha de caducidad</label>
              <input type="date" class="form-control" id="fecha_caducidad" placeholder="Fecha de caducidad del producto" value="" required>
              <div class="invalid-feedback">
                El campo es obligatorio
              </div>
            </div>

            <div class="col-sm-4">
              <label for="tamaño" class="form-label">Tamaño</label>
              <div class="input-group mb-3 has-validation">
                <input type="number" class="form-control" id="tamaño" placeholder="0" step="0.001" min="0" max="10" required>
                <span class="input-group-text">Ltr / Gr</span>
                <div class="invalid-feedback">
                El campo es obligatorio
              </div>
              </div>  
              
            </div>

            <div class="col-sm-4">
              <label for="iva" class="form-label">IVA</label>
              <div class="input-group mb-3 has-validation">
              <span class="input-group-text">%</span>
              <input type="number" class="form-control" id="iva" placeholder="0" step="0.01" min="0" max="10">
              </div>  
            </div>

            <div class="col-sm-4">
              <label for="totalp" class="form-label">Total</label>
              <div class="input-group mb-3 has-validation">
              <span class="input-group-text">$</span>
                <input type="text" class="form-control" id="totalp" placeholder="" required>
                <span class="input-group-text">.00</span>
                <div class="invalid-feedback">
                El campo es olbigatorio
              </div>
              </div>  
            </div>
            
            <!--<input type="submit" class="w-50 btn btn-primary btn-lg" value="Agregar producto">-->
            <button class="w-50 btn btn-primary btn-lg" type="submit">Agregar producto</button>
          </div>
        </form>
      </div>
    </div>
    <div class="row g-5">
      <div class="col-md-7 col-lg-8">
        <form class="needs-validation" novalidate>
          <div class="row g-3">         
            
          <div class="col-4">
              <label for="tipo_entrada" class="form-label">Tipo de entrada</label>
              <select class="form-select" id="tipo_entrada" required>
                  <option value="">-- Selecciona --</option>
                </select>
              <div class="invalid-feedback">
                El campo es obligatorio
              </div>
            </div>

            <div class="col-4">
              <label for="proveedor" class="form-label">Proveedor</label>
              <div class="input-group has-validation">
              <select class="form-select" id="proveedor" required>
                  <option value="">-- Selecciona --</option>
                </select>
              <div class="invalid-feedback">
                  El campo es obligatorio
                </div>
              </div>
            </div>

            <div class="col-4">
              <label for="subtotal" class="form-label">Subtotal</label>
              <div class="input-group has-validation">
                <span class="input-group-text">$</span>
                <input type="text" class="form-control" id="subtotal" placeholder="" required>
                <span class="input-group-text">.00</span>
              <div class="invalid-feedback">
                  El campo es obligatorio
                </div>
              </div>
            </div>

            <div class="col-sm-6">
              <label for="fecha_recepcion" class="form-label">Fecha de recepción</label>
              <input type="date" class="form-control" id="fecha_recepcion" placeholder="Fecha de caducidad del producto" value="" required>
              <div class="invalid-feedback">
                El campo es obligatorio
              </div>
            </div>

            <div class="col-6">
              <label for="folio" class="form-label">Folio <span class="text-muted">(Optional)</span></label>
              <div class="input-group has-validation">
                <input type="text" class="form-control" id="folio" placeholder="">
                
              </div>
            </div>

          <button class="w-100 btn btn-primary btn-lg" type="submit">Agregar</button>
        
          <hr class="my-4">
        </form>
      </div>
    </div>
  </main>
</div>