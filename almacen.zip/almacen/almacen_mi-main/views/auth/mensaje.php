<h1 class="nombre-pagina">Registro exitoso</h1>



<div class="acciones">
    <a href="/">Iniciar sesión</a>
</div>
